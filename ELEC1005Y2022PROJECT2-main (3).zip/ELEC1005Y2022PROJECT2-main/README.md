# ELEC1005Y2022PROJECT2
This is your source code of your Project 2 for ELEC1005 year 2022.
You will need to modify this code to complete your Project 2 assignment.

## Requirements
- Python 3
- pygame

## Usage
To start the game

	$ python main.py
