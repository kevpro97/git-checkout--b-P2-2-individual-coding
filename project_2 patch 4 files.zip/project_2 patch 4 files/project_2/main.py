# -*- coding: utf-8 -*-
"""
Created on Wed May 16 15:22:20 2018
@author: zou
"""

import pygame, random
import time
from pygame.locals import KEYDOWN, K_RIGHT, K_LEFT, K_UP, K_DOWN, K_ESCAPE
from pygame.locals import QUIT

from game import Game
from game import Wall
from game import Settings

black = pygame.Color(0, 0, 0)
white = pygame.Color(255, 255, 255)

green = pygame.Color(0, 200, 0)
bright_green = pygame.Color(0, 255, 0)
red = pygame.Color(200, 0, 0)
bright_red = pygame.Color(255, 0, 0)
blue = pygame.Color(32, 178, 170)
bright_blue = pygame.Color(32, 200, 200)
yellow = pygame.Color(255, 205, 0)
bright_yellow = pygame.Color(255, 255, 0)

game = Game()
rect_len = game.settings.rect_len
snake = game.snake
pygame.init()
fpsClock = pygame.time.Clock()
screen = pygame.display.set_mode((game.settings.width * 15, game.settings.height * 15))
pygame.display.set_caption('Gluttonous')

crash_sound = pygame.mixer.Sound(f'./sound/crash.wav')
# Kevin
# Settings variables
difficulty = "normal"
map = "normal"
# End


def text_objects(text, font, color=black):
    text_surface = font.render(text, True, color)
    return text_surface, text_surface.get_rect()


# Kevin -
# altered to include textsize which allows for different text size displays
def message_display(textsize, text, x, y, color=black):
    large_text = pygame.font.SysFont('comicsansms', textsize)
    text_surf, text_rect = text_objects(text, large_text, color)
    text_rect.center = (x, y)
    screen.blit(text_surf, text_rect)
# redefined buttons
class Button():
    def __init__(self, x, y, image):
        self.image = image
        self.rect = self.image.get_rect()
        self.rect.topleft = (x, y)
    def draw(self):
        screen.blit(self.image, (self.rect.x, self.rect.y))
    # checks if mouse is over button position
    def checkhover(self, position):
        if self.rect.collidepoint(position):
            return True
        return False
# End

def quitgame():
    pygame.quit()
    quit()

# Kevin - improved functionality of crash screen
def crash():
    pygame.mixer.Sound.play(crash_sound)
    pygame.display.set_caption("Game Over")

    intro = True
    while intro:

        screen.fill(black)
        pos = pygame.mouse.get_pos()
        message_display(50, 'GAME OVER', game.settings.width / 2 * 15, game.settings.height / 3 * 15 - 30, white)
        # show the final score
        font = pygame.font.SysFont(None, 25)
        text_score = font.render('Score: ' + str(game.snake.score), True, white)
        screen.blit(text_score, (165, 180))
        # show the difficulty chosen
        text_d = font.render('Difficulty: ' + str(difficulty), True, white)
        screen.blit(text_d, (135, 200))
        # add navigation buttons
        play_button = Button(150, 240, pygame.image.load('images/play.png').convert_alpha())
        menu_button = Button(150, 280, pygame.image.load('images/menu.png').convert_alpha())
        quit_button = Button(150, 320, pygame.image.load('images/quit.png').convert_alpha())
        # hover behaviour of navigation buttons
        if play_button.checkhover(pos):
            play_button = Button(150, 240, pygame.image.load('images/playhover.png').convert_alpha())
        play_button.draw()
        if menu_button.checkhover(pos):
            menu_button = Button(150, 280, pygame.image.load('images/menuhover.png').convert_alpha())
        menu_button.draw()
        if quit_button.checkhover(pos):
            quit_button = Button(150, 320, pygame.image.load('images/quithover.png').convert_alpha())
        quit_button.draw()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                # if buttons are clicked, redirect user to the appropriate page
                if play_button.checkhover(pos):
                    # new game
                    game_loop('human')
                if menu_button.checkhover(pos):
                    # menu
                    initial_interface()
                if quit_button.checkhover(pos):
                    # exit game
                    quitgame()

        pygame.display.update()
# End


# Kevin - altered initial interface, introduced instructions and settings pages
def initial_interface():
    pygame.display.set_caption("Menu")
    intro = True
    while intro:
        screen.blit(pygame.image.load('images/background.png'),(0,0))
        screen.blit(pygame.image.load('images/title.png'), (0, 80))
        pos = pygame.mouse.get_pos()

        play_button = Button(150, 160, pygame.image.load('images/play.png').convert_alpha())
        howto_button = Button(150, 200, pygame.image.load('images/howto.png').convert_alpha())
        options_button = Button(147, 240, pygame.image.load('images/options.png').convert_alpha())
        quit_button = Button(150, 280, pygame.image.load('images/quit.png').convert_alpha())

        # change look of buttons if mouse hovers over
        if play_button.checkhover(pos):
            play_button = Button(150, 160, pygame.image.load('images/playhover.png').convert_alpha())
        play_button.draw()
        if howto_button.checkhover(pos):
            howto_button = Button(150, 200, pygame.image.load('images/howtohover.png').convert_alpha())
        howto_button.draw()
        if options_button.checkhover(pos):
            options_button = Button(147, 240, pygame.image.load('images/optionshover.png').convert_alpha())
        options_button.draw()
        if quit_button.checkhover(pos):
            quit_button = Button(150, 280, pygame.image.load('images/quithover.png').convert_alpha())
        quit_button.draw()


        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                # if menu buttons are clicked, redirect user to the appropriate page
                if play_button.checkhover(pos):
                    game_loop('human')
                if howto_button.checkhover(pos):
                    instructions_page()
                if options_button.checkhover(pos):
                    settings_page()
                if quit_button.checkhover(pos):
                    quitgame()

        pygame.display.update()


def instructions_page():
    pygame.display.set_caption("How to Play")
    intro = True
    while intro:
        # contents of instructions page
        screen.blit(pygame.image.load('images/background.png'), (0, 0))
        screen.blit(pygame.image.load('images/paper.png'), (8, 8))

        message_display(20, 'Instructions', game.settings.width / 2 * 15, game.settings.height / 4 + 45)
        message_display(10, 'The snake can be moved by the arrow keys. The aim is to eat as much food ',
                        game.settings.width / 2 * 15, game.settings.height / 4 + 65)
        message_display(10, 'as possible without dying to a wall, the edges or the snake itself.',
                        game.settings.width / 2 * 15, game.settings.height / 4 + 80)
        message_display(15, 'Normal Mode', game.settings.width / 2 * 15, game.settings.height / 4 + 100)
        message_display(10, '1. Snake has medium speed, 2. 2-4 walls are generated, 3. Only apples can be eaten,',
                        game.settings.width / 2 * 15, game.settings.height / 4 + 125)
        message_display(10, '4. Start off with 2 lives', game.settings.width / 2 * 15, game.settings.height / 4 + 140)
        message_display(15, 'Easy Mode', game.settings.width / 2 * 15, game.settings.height / 4 + 165)
        message_display(10, '1. Snake has slow speed, 2. No walls are generated, 3. Buff food (Hearts, cherries and  ',
                        game.settings.width / 2 * 15, game.settings.height / 4 + 190)
        message_display(10, 'peels) alongside apples can also be eaten, 4. Start off with 3 lives',
                        game.settings.width / 2 * 15, game.settings.height / 4 + 205)
        message_display(15, 'Hard Mode', game.settings.width / 2 * 15, game.settings.height / 4 + 230)
        message_display(10, '1. Snake has fast speed, 2. 6-8 walls are generated, 3. Debuff food (Coffee, avocado) ',
                        game.settings.width / 2 * 15, game.settings.height / 4 + 255)
        message_display(10, 'alongside apples can also be eaten, 4. Only 1 life given', game.settings.width / 2 * 15,
                        game.settings.height / 4 + 270)
        message_display(15, 'Food', game.settings.width / 2 * 15, game.settings.height / 4 + 295)
        message_display(10, '1. Heart - gain 1 life, 2. Cherry - gain an additional point (2 instead of 1)',
                        game.settings.width / 2 * 15, game.settings.height / 4 + 320)
        message_display(10, '3. Peels - slow down snake speed, 4. Apple - standard food, 5. Avocado - gain an ',
                        game.settings.width / 2 * 15, game.settings.height / 4 + 335)
        message_display(10, 'additional snake segment (2 instead of 1) and 6. Coffee - speed up snake speed',
                        game.settings.width / 2 * 15, game.settings.height / 4 + 350)
        pos = pygame.mouse.get_pos()

        back_button = Button(150, 370, pygame.image.load('images/back.png').convert_alpha())
        if back_button.checkhover(pos):
            back_button = Button(150, 370, pygame.image.load('images/backhover.png').convert_alpha())
        back_button.draw()
        events = pygame.event.get()
        for event in events:
            if event.type == pygame.QUIT:
                pygame.quit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if back_button.checkhover(pos):
                    initial_interface()
        pygame.display.update()


def settings_page():
    pygame.display.set_caption("Settings")
    intro = True
    while intro:
        pos = pygame.mouse.get_pos()
        screen.blit(pygame.image.load('images/background.png'), (0, 0))
        # contents of settings page
        screen.blit(pygame.image.load('images/settings.png'), (0, 20))
        message_display(20, 'Difficulty:', 50, 115)

        global difficulty, map

        normald_button = Button(100, 100, pygame.image.load('images/normal.png').convert_alpha())
        if map == 'normal':
            normald_button = Button(100, 100, pygame.image.load('images/normalhover.png').convert_alpha())
        if normald_button.checkhover(pos):
            normald_button = Button(100, 100, pygame.image.load('images/normalhover.png').convert_alpha())
        normald_button.draw()

        easy_button = Button(200, 100, pygame.image.load('images/easy.png').convert_alpha())
        if difficulty == 'easy':
            easy_button = Button(200, 100, pygame.image.load('images/easyhover.png').convert_alpha())
        if easy_button.checkhover(pos):
            easy_button = Button(200, 100, pygame.image.load('images/easyhover.png').convert_alpha())
        easy_button.draw()

        hard_button = Button(285, 100, pygame.image.load('images/hard.png').convert_alpha())
        if difficulty == 'hard':
            hard_button = Button(285, 100, pygame.image.load('images/hardhover.png').convert_alpha())
        if hard_button.checkhover(pos):
            hard_button = Button(285, 100, pygame.image.load('images/hardhover.png').convert_alpha())
        hard_button.draw()

        message_display(20, 'Map:', 30, 200)

        normal_button = Button(50, 185, pygame.image.load('images/normal.png').convert_alpha())
        if map == 'normal':
            normal_button = Button(50, 185, pygame.image.load('images/normalhover.png').convert_alpha())
        if normal_button.checkhover(pos):
            normal_button = Button(50, 185, pygame.image.load('images/normalhover.png').convert_alpha())
        normal_button.draw()

        ice_button = Button(130, 185, pygame.image.load('images/ice.png').convert_alpha())
        if map == 'ice':
            ice_button = Button(130, 185, pygame.image.load('images/icehover.png').convert_alpha())
        if ice_button.checkhover(pos):
            ice_button = Button(130, 185, pygame.image.load('images/icehover.png').convert_alpha())
        ice_button.draw()

        desert_button = Button(225, 185, pygame.image.load('images/desert.png').convert_alpha())
        if map == 'desert':
            desert_button = Button(225, 185, pygame.image.load('images/deserthover.png').convert_alpha())
        if desert_button.checkhover(pos):
            desert_button = Button(225, 185, pygame.image.load('images/deserthover.png').convert_alpha())
        desert_button.draw()

        fire_button = Button(320, 185, pygame.image.load('images/fire.png').convert_alpha())
        if map == 'fire':
            fire_button = Button(320, 185, pygame.image.load('images/firehover.png').convert_alpha())
        if fire_button.checkhover(pos):
            fire_button = Button(320, 185, pygame.image.load('images/firehover.png').convert_alpha())
        fire_button.draw()

        back_button = Button(150, 270, pygame.image.load('images/back.png').convert_alpha())
        if back_button.checkhover(pos):
            back_button = Button(150, 270, pygame.image.load('images/backhover.png').convert_alpha())
        back_button.draw()

        events = pygame.event.get()
        for event in events:
            if event.type == pygame.QUIT:
                pygame.quit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                # if an option is selected, this is saved
                if normald_button.checkhover(pos):
                    difficulty = 'normal'
                if easy_button.checkhover(pos):
                    difficulty = 'easy'
                if hard_button.checkhover(pos):
                    difficulty = 'hard'
                if normal_button.checkhover(pos):
                    map = 'normal'
                if ice_button.checkhover(pos):
                    map = 'ice'
                if desert_button.checkhover(pos):
                    map = 'desert'
                if fire_button.checkhover(pos):
                    map = 'fire'
                if back_button.checkhover(pos):
                    initial_interface()

        pygame.display.update()
# End


def game_loop(player, fps=10):
    pygame.display.set_caption("Gluttonous")
    game.restart_game()
    # Kevin - apply settings to game
    game_settings = Settings()
    game_settings.difficulty(difficulty)
    game_settings.map(map)
    # End

    # Integration
    # easy mode: no walls spawn and slow snake base speed
    if difficulty == "easy":
        game.random_walls(0)
        fps = 4
    # normal mode: 2-4 walls spawn and medium snake base speed
    elif difficulty == "normal":
        game.random_walls(random.randint(2, 4))
        fps = 6
    # hard mode: 6-8 walls spawn and fast snake base speed
    elif difficulty == "hard":
        game.random_walls(random.randint(6, 8))
        fps = 8

    game_settings.fps(fps)

    while not game.game_end():

        pygame.event.pump()

        move = human_move()

        game.do_move(move)

        if map == "ice":
            screen.fill(0xADD8E6)
        elif map == "fire":
            screen.fill(0xFF814A)
        elif map == "desert":
            screen.fill(0xFFE14B)
        else:
            screen.fill(black)
        fps = game_settings.grab_fps()
        # Jerry's modification
        index = 0
        while index < len(game.walls):
            game.walls[index].blit(screen, map)
            index += 1
        # END

        game.snake.blit(rect_len, screen)
        game.strawberry.blit(screen)
        game.blit_score(white, screen)

        pygame.display.flip()

        fpsClock.tick(fps)

    crash()


def human_move():
    direction = snake.facing

    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()

        elif event.type == KEYDOWN:
            if event.key == K_RIGHT or event.key == ord('d'):
                direction = 'right'
            if event.key == K_LEFT or event.key == ord('a'):
                direction = 'left'
            if event.key == K_UP or event.key == ord('w'):
                direction = 'up'
            if event.key == K_DOWN or event.key == ord('s'):
                direction = 'down'
            if event.key == K_ESCAPE:
                pygame.event.post(pygame.event.Event(QUIT))

    move = game.direction_to_int(direction)
    return move


if __name__ == "__main__":
    initial_interface()
